<?php
/**
 * Created by PhpStorm.
 * User: TrinhNg
 */

$hn = 'localhost';
$un = 'root';
$pw = 'hello';
$db = 'phpweb';